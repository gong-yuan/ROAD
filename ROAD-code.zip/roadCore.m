% This function implements the ROAD
% Algorithm for the following optimization problem:
% minimize 0.5 * w' \Sigma w + \lambda |w|_1 + 1/2 \gamma (Aw-b)^T (Aw-b)
% x: n*p matrix
% y: label for the data, 0/1, or 1/2.
function [wPath, num] = roadCore(A, b, Sigma, lamList, para)
%%%%%%%%%%K: number of lambdas on the log-scale
%%%%%%%%%%epsilon: lamMin=lamMax*epsilon

iterMax = para.iterMax;
epsCon = para.epsCon;
epsilon = para.epsilon;
K = para.K;
gamma = para.gamma;
p = para.p;

A1List = gamma*A;
cons = A1List.^2/gamma + diag(Sigma);

%%%starting the algorithm
wPath = zeros(p,K);
w0=zeros(p,1);
num = zeros(K,1);

for i=1:K
    %     if(trace=='T' && mod(i,10)==0)
    %         disp(['i=',num2str(i),'number of nonzero coefficients:',num2str(length(find(w0(abs(w0)>0))))]);
    %     end
    lambda=lamList(i);
    error=1;
    iterInd = 1;
    while(error > epsCon && iterInd < iterMax)
        %%%%starting coordinate-wise descent
        iterInd = iterInd+1;
        wlast = w0;
        %  randCycle = randsample(p,p);
        %  for randInd = 1:p
        %     j=randCycle(randInd);
        %  %%code for randomized update, experiments show that they are no
        %  difference both in terms of result and speed
        
        for j = 1:p
            uHat = A1List(j)*b - (Sigma(:,j)+gamma*A(j)*A)'*w0 + (Sigma(j,j)+gamma*A(j)^2)*w0(j);
            %uHatold = A1List(j)*b - (SigList(:,j) +A3List(:,j))'*w0(Index(:,j));
            %The original code (using indexing), which is slower than the new one...
            %epsi = uHat - uHatold; (check the two codes are the same)
            w0(j) = sign(uHat)*max(0,(abs(uHat)-lambda))/cons(j);
            %w0(j) = wthresh(uHat, 's', lambda)/cons(j);
            % display(['Varnum=', num2str(j), ' Temp=', num2str(uHat)]);
            % display(['Varnum=', num2str(j), ' New estimate=', num2str(w0(j))]);
        end
        error = sum(abs(w0-wlast));
        
        % display(['Iter= ', num2str(iterInd),' Error= ', num2str(error)]);
    end
    if(iterInd == iterMax)
        display(['Unable to converge...at step', num2str(i)]);
    end
    
    wPath(:,i) = w0;
    num(i) = length(find(w0));
    % plot(wPath)
end

















